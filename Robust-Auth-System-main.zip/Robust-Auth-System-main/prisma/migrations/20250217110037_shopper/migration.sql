-- AlterTable
ALTER TABLE "User" ALTER COLUMN "username" DROP NOT NULL;
